#include <iostream>

using namespace std;

int main(){
    
    int num;
    cin >> num;
    
    if(num == 3 || num == 5){
        cout << "SIM" << endl;
    }else{
        cout << "NAO" << endl;
    }
    
    
    
    return 0;
}