#include <iostream>

using namespace std;

int main(){
    
    int num;
    cin >> num;
    
    if(num >= 0){
        cout << "SIM" << endl;
    }else{
        cout << endl;
    }
    
    return 0;
}